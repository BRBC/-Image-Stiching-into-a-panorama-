﻿#include<iostream>
#include <QApplication>
#include<stdio.h>
#include "opencv2/core/core.hpp"
#include "opencv2/features2d/features2d.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/opencv.hpp"
#define _CRT_SECURE_NO_WARNINGS

using namespace std;
using namespace cv;

Mat makePanorama(Mat img1, Mat img2) {
    //numar de puncte cheie
    int nrDePuncte = 1800;

    //initializarea detectorului pointer tip ORB
    Ptr<ORB> detectorPuncteCheie = ORB::create(nrDePuncte);

    //vector in care vom stoca punctele cheie a imaginilor 
    vector<KeyPoint> keypoints_img1;
    vector<KeyPoint> keypoints_img2;

    detectorPuncteCheie->detect(img1, keypoints_img1);
    detectorPuncteCheie->detect(img2, keypoints_img2);

    Mat kImg1 = img1.clone();
    drawKeypoints(img1, keypoints_img1, kImg1);
    imwrite("C:/Disc D/Anul 3/ProiectePim/try7/ACPI/ACPI/ACPI/Images/keypointsImg1.jpg", kImg1);

    Mat kImg2 = img2.clone();
    drawKeypoints(img2, keypoints_img2, kImg2);
    imwrite("C:/Disc D/Anul 3/ProiectePim/try7/ACPI/ACPI/ACPI/Images/keypointsImg2.jpg", kImg2);

    //vector de stocare a descriptorilor punctelor cheie a imaginilor
    Mat descriptor_img1;
    Mat descriptor_img2;

    //initializarea extractorului descriptorilor
    Ptr<DescriptorExtractor> extractor = ORB::create();

    //calcularea descriptorilor punctelor cheie respective
    extractor->compute(img1, keypoints_img1, descriptor_img1);
    extractor->compute(img2, keypoints_img2, descriptor_img2);

    //Potrivirea descriptorilor cu Brute-Force matcher, aplicând distanța Hamming
    BFMatcher matcher(NORM_HAMMING);

    //Vector de DMatch-clasa speciala pentru potrivirea descriptorilor 
    vector< DMatch > matches;

    //Vectorul matches va stoca toate cele mai bune potriviri ale descriptorilor
    matcher.match(descriptor_img1, descriptor_img2, matches);

    imshow("Imagine 1", img1);
    waitKey(0);
    imshow("Imagine 2", img2);
    waitKey(0);
    destroyWindow("Imagine 1");
    destroyWindow("Imagine 2");

    Mat img_matches;
    //Deseneaza legaturile intre perechile din vectorul matches
    drawMatches(img1, keypoints_img1, img2, keypoints_img2, matches, img_matches);

    imshow("Potriviri", img_matches);
    waitKey(0);
    imwrite("C:/Disc D/Anul 3/ProiectePim/try7/ACPI/ACPI/ACPI/Images/img_matches.jpg", img_matches);
    destroyWindow("Potriviri");

    //double min_dist = INT16_MAX;
    ////Calculam minimul distantei intre potriviri
    //for (int i = 0; i < matches.size(); i++)
    //{
    //    double dist = matches[i].distance;

    //    if (dist < min_dist)
    //    {
    //        min_dist = dist;
    //    }
    //}

    ////Refiltrare a potrivirilor pe baza distantei<3*min_dist )
    //std::vector< DMatch > good_matches;
    //for (int i = 0; i < matches.size(); i++)
    //{
    //    if (matches[i].distance < 3 * min_dist)
    //    {
    //        good_matches.push_back(matches[i]);
    //    }
    //}

    //vector de coordonate
    vector<Point2f> points_img1, points_img2;
    for (unsigned int i = 0; i < matches.size(); i++) {
        //Adauga in vectorul points_img1, coordonatele keypoint-ului 1 al perechii matches[i]
        points_img1.push_back(keypoints_img1[matches[i].queryIdx].pt);
        points_img2.push_back(keypoints_img2[matches[i].trainIdx].pt);
    }


    //Utilizam metoda RANSAC pentru aflarea matricei homografice
    Mat mat_homographic = findHomography(points_img1, points_img2, RANSAC);
    cout << "H = " << endl << " " << mat_homographic << endl << endl;


    cv::Mat parteComuna;
    parteComuna = img1.clone();//ofera structura

    //folosim matricea homografica pentru a obtine partea comuna
    warpPerspective(img1, parteComuna, mat_homographic, cv::Size(img1.cols + img2.cols, img1.rows));
    imshow("Parte comuna", parteComuna);
    waitKey(0);
    destroyWindow("Parte comuna");

    //copie pentru pastrarea imaginii obtinute
    cv::Mat copy = parteComuna.clone();

    //conversie grayscale
    cv::cvtColor(parteComuna, parteComuna, cv::COLOR_BGR2GRAY);

    //Binarizare cu prag 1
    cv::Mat binaryMask;
    cv::threshold(parteComuna, binaryMask, 1, 255, cv::THRESH_BINARY_INV);

    //folosim element morfologic
    cv::Mat element = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3));

    //numarul iteratiilor operatiilor morfologice
    int iterations = 5;

    cv::morphologyEx(binaryMask, binaryMask, cv::MORPH_ERODE, element, cv::Point(-1, -1), iterations);
    cv::morphologyEx(binaryMask, binaryMask, cv::MORPH_DILATE, element, cv::Point(-1, -1), iterations);

    //Inversare pentru obtinerea conturului
    binaryMask = 255 - binaryMask;
    imshow("Binary mask", binaryMask);
    waitKey(0);
    destroyWindow("Binary mask");

    std::vector< std::vector<cv::Point> > contours;
    std::vector<cv::Vec4i> hierarchy;

    cv::findContours(binaryMask, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, cv::Point(0, 0));

    int index_max_area = 0;
    double max_area = 0.0;

    //Aflam indexul celui mai mare contur 
    //Parcurgem lista de vectori de coordonate a contururilor
    for (int i = 0; i < (int)contours.size(); i++) {

        //Cautam cea mai mare arie a contururilor
        double arie = cv::contourArea(contours[i], false);
        //Pastreaza indexul
        if (arie > max_area) {
            max_area = arie;
            index_max_area = i;
        }

    }

    //Construim perimetrul in baza conturului
    cv::Rect crop_area = cv::boundingRect(contours[index_max_area]);

    //Decupam imaginea
    cv::Mat croppedImage = copy(crop_area);

    imshow("Partea Comuna", croppedImage);
    waitKey(0);
    destroyWindow("Partea Comuna");

    //Decupam prima imagine pana la intalnirea partii comune
    cv::Mat crop_img1 = img1(Rect(0, 0, img1.cols - croppedImage.cols, img1.rows));
    //Construim dimensiunea panoramei
    Mat final_result(Size(crop_img1.cols + img2.cols, crop_img1.rows), img1.type());
    //Alaturam imaginile 
    crop_img1.copyTo(final_result(Rect(0, 0, crop_img1.cols, crop_img1.rows)));
    img2.copyTo(final_result(Rect(crop_img1.cols, 0, img2.cols, img2.rows)));

    return final_result;

}

Mat makePanorama2(Mat img1, Mat img2) {
    Mat pano;
    vector<Mat> imgs;
    imgs.push_back(img1);
    imgs.push_back(img2);
    Ptr<Stitcher> stitcher = Stitcher::create(Stitcher::PANORAMA);
    Stitcher::Status status = stitcher->stitch(imgs, pano);

    if (status != Stitcher::OK)
    {
        cout << "Can't stitch images, error code = " << int(status) << endl;
    }
    return pano;

}

int main()
{

    cv::Mat img1;
    cv::Mat img2;
    cv::Mat img3;


    img1 = imread("C:/Disc D/Anul 3/ProiectePim/try7/ACPI/ACPI/ACPI/Images/im1.jpg");
    img2 = imread("C:/Disc D/Anul 3/ProiectePim/try7/ACPI/ACPI/ACPI/Images/im2.jpg");
    img3 = imread("C:/Disc D/Anul 3/ProiectePim/try7/ACPI/ACPI/ACPI/Images/im3.jpg");

    auto start = std::chrono::steady_clock::now();
    Mat res12 = makePanorama(img1, img2);
    imwrite("C:/Disc D/Anul 3/ProiectePim/try7/ACPI/ACPI/ACPI/Images/res12.jpg", res12);
    auto end = std::chrono::steady_clock::now();
    imshow("Make Panorama1", res12);
    waitKey(0);
    std::chrono::duration<double> elapsed_seconds = end - start;
    std::cout << "elapsed time: " << elapsed_seconds.count() << "s\n";

    auto start2 = std::chrono::steady_clock::now();
    Mat pano = makePanorama2(img1, img2);
    auto end2 = std::chrono::steady_clock::now();
    imshow("Make Panorama2", pano);
    waitKey(0);
    std::chrono::duration<double> elapsed_seconds2 = end2 - start2;
    std::cout << "elapsed time: " << elapsed_seconds2.count() << "s\n";
    Mat res23 = makePanorama(img2, img3);
    Mat resF123 = makePanorama(res12, res23);

    imshow("IMG Final", resF123);
    waitKey(0);

    Mat img4 = cv::imread("C:/Disc D/Anul 3/ProiectePim/try7/ACPI/ACPI/ACPI/Images/original_image_left.jpg");
    Mat img5 = cv::imread("C:/Disc D/Anul 3/ProiectePim/try7/ACPI/ACPI/ACPI/Images/original_image_right.jpg");

    Mat res45 = makePanorama(img4, img5);

    imshow("IMG Final", res45);
    waitKey(0);


    return 0;
}